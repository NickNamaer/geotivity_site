# -*- coding: utf-8 -*-

import json
import os
import zipfile
from pathlib import Path
from typing import Dict, List, Optional
from urllib.parse import urljoin

import requests


class NodeODMError(Exception):
    pass


class NodeODMClient:
    """Small REST client for NodeODM.

    Uses the documented NodeODM endpoints:
    - POST /task/new/init
    - POST /task/new/upload/{uuid}
    - POST /task/new/commit/{uuid}
    - GET  /task/{uuid}/info
    - GET  /task/{uuid}/download/all.zip
    - POST /task/cancel/{uuid} or /task/{uuid}/cancel, best-effort
    """

    def __init__(self, base_url: str, token: str = '', timeout: int = 30):
        self.base_url = base_url.rstrip('/') + '/'
        self.token = token.strip()
        self.timeout = timeout

    def _url(self, path: str) -> str:
        return urljoin(self.base_url, path.lstrip('/'))

    def _params(self) -> Dict[str, str]:
        return {'token': self.token} if self.token else {}

    def _raise_for_response(self, response: requests.Response, action: str):
        if response.ok:
            return
        detail = response.text.strip()
        try:
            data = response.json()
            detail = data.get('error') or data.get('message') or detail
        except Exception:
            pass
        raise NodeODMError(f'{action}に失敗しました: HTTP {response.status_code} {detail}')

    def test_connection(self) -> Dict:
        # /info is available on NodeODM. Some older installations may respond differently,
        # so fall back to root access if needed.
        for path in ('/info', '/'):
            try:
                r = requests.get(self._url(path), params=self._params(), timeout=self.timeout)
                if r.ok:
                    try:
                        return r.json()
                    except Exception:
                        return {'status': 'ok', 'response': r.text[:500]}
            except requests.RequestException:
                continue
        raise NodeODMError('NodeODMに接続できません。URL、Docker起動状態、ポート番号を確認してください。')

    def init_task(self, name: str, options: Optional[List[Dict]] = None, outputs: Optional[List[str]] = None) -> str:
        data = {'name': name}
        if options:
            data['options'] = json.dumps(options, ensure_ascii=False)
        if outputs:
            data['outputs'] = json.dumps(outputs, ensure_ascii=False)
        r = requests.post(self._url('/task/new/init'), data=data, params=self._params(), timeout=self.timeout)
        self._raise_for_response(r, 'タスク作成')
        uuid = r.json().get('uuid')
        if not uuid:
            raise NodeODMError('NodeODMからタスクUUIDを取得できませんでした。')
        return uuid

    def upload_files(self, uuid: str, files: List[str], progress_callback=None):
        total = len(files)
        for index, path in enumerate(files, start=1):
            filename = os.path.basename(path)
            file_size = os.path.getsize(path)
            # 最低速度10MB/s相当で計算し、300秒を下限とする（大容量画像対応）
            size_based_timeout = max(300, int(file_size / (10 * 1024 * 1024)) + 60)
            with open(path, 'rb') as f:
                multipart = {'images': (filename, f, 'application/octet-stream')}
                r = requests.post(
                    self._url(f'/task/new/upload/{uuid}'),
                    files=multipart,
                    params=self._params(),
                    timeout=size_based_timeout,
                )
            self._raise_for_response(r, f'画像アップロード: {filename}')
            if progress_callback:
                progress_callback(index, total, filename)

    def commit_task(self, uuid: str):
        r = requests.post(self._url(f'/task/new/commit/{uuid}'), params=self._params(), timeout=self.timeout)
        self._raise_for_response(r, 'ODM処理開始')
        return r.json() if r.text else {'uuid': uuid}

    def task_info(self, uuid: str) -> Dict:
        r = requests.get(self._url(f'/task/{uuid}/info'), params=self._params(), timeout=self.timeout)
        self._raise_for_response(r, 'タスク情報取得')
        return r.json()

    def cancel_task(self, uuid: str):
        last_error = None
        for path in (f'/task/cancel/{uuid}', f'/task/{uuid}/cancel'):
            try:
                r = requests.post(self._url(path), params=self._params(), timeout=self.timeout)
                if r.ok:
                    return True
                last_error = r.text
            except Exception as exc:
                last_error = str(exc)
        raise NodeODMError(f'タスク中止に失敗しました: {last_error}')

    def download_all_zip(self, uuid: str, destination_zip: str):
        r = requests.get(
            self._url(f'/task/{uuid}/download/all.zip'),
            params=self._params(),
            timeout=max(self.timeout, 300),
            stream=True,
        )
        self._raise_for_response(r, '成果物ダウンロード')
        Path(destination_zip).parent.mkdir(parents=True, exist_ok=True)
        with open(destination_zip, 'wb') as f:
            for chunk in r.iter_content(chunk_size=1024 * 1024):
                if chunk:
                    f.write(chunk)
        return destination_zip

    @staticmethod
    def extract_zip(zip_path: str, extract_dir: str):
        """Extract NodeODM all.zip safely.

        NodeODM output is trusted in normal local use, but this still guards against
        zip-slip style paths so the plugin can be published with safer defaults.
        """
        dest = Path(extract_dir).resolve()
        dest.mkdir(parents=True, exist_ok=True)
        with zipfile.ZipFile(zip_path, 'r') as zf:
            for member in zf.infolist():
                target = (dest / member.filename).resolve()
                if not str(target).startswith(str(dest)):
                    raise NodeODMError(f'危険なZIP内パスを検出したため解凍を中止しました: {member.filename}')
            zf.extractall(dest)
        return str(dest)
