# -*- coding: utf-8 -*-

import os
import json
import shutil
import time
from datetime import datetime
from pathlib import Path
from typing import Dict, List

from qgis.PyQt.QtCore import QObject, pyqtSignal

from .nodeodm_client import NodeODMClient, NodeODMError


STATUS_DONE = {40, '40', 'COMPLETED', 'completed', 'success', 'SUCCESS'}
STATUS_FAILED = {30, '30', 50, '50', 'FAILED', 'failed', 'canceled', 'CANCELED'}


def _extract_status_code(status):
    """NodeODM の status フィールドを正規化する。

    NodeODM v2+ は ``{'code': int}`` 形式の dict を返す。
    旧バージョンや一部の実装では整数または文字列を直接返す場合がある。
    """
    if isinstance(status, dict):
        return status.get('code')
    return status


def now_text():
    return datetime.now().strftime('%Y-%m-%d %H:%M:%S')


def log_text(message: str) -> str:
    return f'{now_text()} {message}'


class ODMWorker(QObject):
    log = pyqtSignal(str)
    progress = pyqtSignal(int, str)
    stage_progress = pyqtSignal(str, int)
    finished = pyqtSignal(dict)
    error = pyqtSignal(str)

    def __init__(self, params: Dict):
        super().__init__()
        self.params = params
        self._cancel_requested = False
        self._task_uuid = None
        self._client = None
        self._log_lines: List[str] = []

    def request_cancel(self):
        self._cancel_requested = True
        try:
            if self._client and self._task_uuid:
                self._client.cancel_task(self._task_uuid)
                self._emit_log('NodeODMタスク中止を要求しました')
        except Exception as exc:
            self._emit_log(f'NodeODMタスク中止要求に失敗しました: {exc}')

    def _emit_log(self, message: str):
        line = log_text(message)
        self._log_lines.append(line)
        self.log.emit(line)

    def _check_cancel(self):
        if self._cancel_requested:
            raise NodeODMError('ユーザー操作により処理を中止しました。')

    def run(self):
        try:
            base_url = self.params['nodeodm_url']
            image_folder = self.params['image_folder']
            output_folder = self.params['output_folder']
            mode = self.params.get('mode', 'standard')
            load_flags = self.params.get('load_flags', {})
            project_name = self.params.get('project_name') or f'odm_{datetime.now().strftime("%Y%m%d_%H%M%S")}'

            project_dir = Path(output_folder) / project_name
            raw_dir = project_dir / '_nodeodm_raw'
            logs_dir = project_dir / 'logs'
            raw_dir.mkdir(parents=True, exist_ok=True)
            logs_dir.mkdir(parents=True, exist_ok=True)

            self.progress.emit(0, '接続確認中')
            self._emit_log('NodeODM接続確認中')
            self._client = NodeODMClient(base_url)
            self._client.test_connection()
            self._emit_log('NodeODM接続成功')
            self._check_cancel()

            images = self._collect_images(image_folder)
            if not images:
                raise NodeODMError('画像フォルダ内に jpg / jpeg / tif / tiff が見つかりません。')
            total_size = sum(os.path.getsize(p) for p in images)
            self._emit_log(f'画像{len(images)}枚検出 / 合計 {total_size / (1024 ** 3):.2f} GB')

            options = self._build_options(mode)
            outputs = self._default_outputs()
            self.progress.emit(5, 'タスク作成中')
            self._task_uuid = self._client.init_task(project_name, options=options, outputs=outputs)
            self._emit_log(f'タスク作成完了: {self._task_uuid}')
            self.stage_progress.emit('upload', 0)
            self._check_cancel()

            self.progress.emit(10, '画像アップロード中')
            self._emit_log('アップロード開始')

            def upload_progress(index, total, filename):
                percent = int(index / max(total, 1) * 100)
                overall = 10 + int(percent * 0.25)
                self.stage_progress.emit('upload', percent)
                self.progress.emit(overall, f'画像アップロード中 {index}/{total}: {filename}')
                if index % 10 == 0 or index == total:
                    self._emit_log(f'アップロード進捗 {index}/{total}')
                self._check_cancel()

            self._client.upload_files(self._task_uuid, images, progress_callback=upload_progress)
            self.stage_progress.emit('upload', 100)
            self._emit_log('アップロード完了')
            self._check_cancel()

            self.progress.emit(38, 'ODM処理開始中')
            self._client.commit_task(self._task_uuid)
            self._emit_log('ODM処理開始')
            self.stage_progress.emit('processing', 0)

            start_time = time.time()
            last_status = None
            while True:
                self._check_cancel()
                info = self._client.task_info(self._task_uuid)
                status = _extract_status_code(info.get('status'))
                progress = self._parse_processing_progress(info, start_time)
                message = self._status_message(info)
                self.stage_progress.emit('processing', progress)
                self.progress.emit(40 + int(progress * 0.35), message)
                if message != last_status:
                    self._emit_log(message)
                    last_status = message
                if status in STATUS_DONE:
                    break
                if status in STATUS_FAILED:
                    raise NodeODMError(f'ODM処理に失敗しました: {info.get("last_error") or info}')
                time.sleep(5)

            self.stage_progress.emit('processing', 100)
            self._emit_log('ODM処理完了')

            self.progress.emit(78, '成果物ダウンロード中')
            self.stage_progress.emit('download', 0)
            zip_path = raw_dir / 'all.zip'
            self._client.download_all_zip(self._task_uuid, str(zip_path))
            self.stage_progress.emit('download', 50)
            self._emit_log('成果物ZIP取得完了')

            extract_dir = raw_dir / 'extracted'
            self._client.extract_zip(str(zip_path), str(extract_dir))
            self.stage_progress.emit('download', 80)
            self._emit_log('成果物ZIP解凍完了')

            outputs_map = self._organize_outputs(extract_dir, project_dir)
            self.stage_progress.emit('download', 100)
            self._emit_log('成果物整理完了')

            if load_flags.get('chm') and outputs_map.get('dsm') and outputs_map.get('dtm'):
                self.progress.emit(92, 'CHM作成準備完了')
                self.stage_progress.emit('chm', 0)
                # CHM actual raster calculation is done on QGIS main side.
                self.stage_progress.emit('chm', 100)

            manifest_path = project_dir / 'geotivity_nodeodm_manifest.json'
            self._write_manifest(manifest_path, project_name, mode, outputs_map, load_flags)
            self._emit_log(f'実行マニフェスト作成: {manifest_path}')
            self._write_log(logs_dir / 'process_log.txt')
            self.progress.emit(100, '完了')
            self.finished.emit({
                'project_dir': str(project_dir),
                'outputs': outputs_map,
                'load_flags': load_flags,
                'log_path': str(logs_dir / 'process_log.txt'),
                'task_uuid': self._task_uuid,
            })
        except Exception as exc:
            try:
                output_folder = self.params.get('output_folder')
                if output_folder:
                    fallback_log = Path(output_folder) / 'nodeodm_error_log.txt'
                    fallback_log.write_text('\n'.join(self._log_lines + [log_text(str(exc))]), encoding='utf-8')
            except Exception:
                pass
            self.error.emit(str(exc))

    @staticmethod
    def _collect_images(folder: str) -> List[str]:
        exts = {'.jpg', '.jpeg', '.tif', '.tiff'}
        return sorted(str(p) for p in Path(folder).rglob('*') if p.is_file() and p.suffix.lower() in exts)

    @staticmethod
    def _build_options(mode: str) -> List[Dict]:
        presets = {
            'fast': [
                {'name': 'fast-orthophoto', 'value': True},
                {'name': 'orthophoto-resolution', 'value': 10},
            ],
            'standard': [
                {'name': 'dsm', 'value': True},
                {'name': 'dtm', 'value': True},
                {'name': 'orthophoto-resolution', 'value': 5},
            ],
            'high': [
                {'name': 'dsm', 'value': True},
                {'name': 'dtm', 'value': True},
                {'name': 'pc-quality', 'value': 'high'},
                {'name': 'orthophoto-resolution', 'value': 2},
            ],
            'forest': [
                {'name': 'dsm', 'value': True},
                {'name': 'dtm', 'value': True},
                {'name': 'pc-quality', 'value': 'high'},
                {'name': 'dem-resolution', 'value': 5},
                {'name': 'orthophoto-resolution', 'value': 5},
            ],
            'chm': [
                {'name': 'dsm', 'value': True},
                {'name': 'dtm', 'value': True},
                {'name': 'pc-quality', 'value': 'high'},
                {'name': 'dem-resolution', 'value': 2},
                {'name': 'orthophoto-resolution', 'value': 5},
                {'name': 'feature-quality', 'value': 'high'},
            ],
        }
        return presets.get(mode, presets['standard'])

    @staticmethod
    def _default_outputs() -> List[str]:
        return [
            'odm_orthophoto/odm_orthophoto.tif',
            'odm_dem/dsm.tif',
            'odm_dem/dtm.tif',
            'odm_georeferencing/odm_georeferenced_model.laz',
            'odm_georeferencing/odm_georeferenced_model.las',
        ]

    @staticmethod
    def _parse_processing_progress(info: Dict, start_time: float) -> int:
        for key in ('progress', 'progressPct'):
            if key in info:
                try:
                    value = float(info[key])
                    if value <= 1:
                        value *= 100
                    return max(0, min(100, int(value)))
                except Exception:
                    pass
        # Fallback: slow optimistic progress, capped at 95 until completion.
        elapsed = time.time() - start_time
        return max(0, min(95, int(elapsed / 60 * 5)))

    @staticmethod
    def _status_message(info: Dict) -> str:
        status = _extract_status_code(info.get('status'))
        msg = info.get('statusLabel') or info.get('running_progress') or info.get('last_error') or ''
        if msg:
            return f'ODM処理中: {msg}'
        return f'ODM処理中: status={status}'

    def _organize_outputs(self, extract_dir: Path, project_dir: Path) -> Dict[str, str]:
        targets = {
            'orthophoto': ('orthophoto', 'orthophoto.tif', ['odm_orthophoto.tif', 'orthophoto.tif']),
            'dsm': ('elevation', 'dsm.tif', ['dsm.tif']),
            'dtm': ('elevation', 'dtm.tif', ['dtm.tif']),
            'pointcloud': ('pointcloud', 'pointcloud.laz', ['odm_georeferenced_model.laz', 'pointcloud.laz']),
        }
        outputs = {}
        for key, (subdir, out_name, candidates) in targets.items():
            found = self._find_first(extract_dir, candidates)
            if not found:
                if key == 'pointcloud':
                    found = self._find_first(extract_dir, ['odm_georeferenced_model.las', 'pointcloud.las'])
                    out_name = 'pointcloud.las'
            if found:
                dst_dir = project_dir / subdir
                dst_dir.mkdir(parents=True, exist_ok=True)
                dst = dst_dir / out_name
                shutil.copy2(str(found), str(dst))
                outputs[key] = str(dst)
                self._emit_log(f'成果物検出: {key} -> {dst}')
            else:
                self._emit_log(f'成果物未検出: {key}')
        return outputs

    @staticmethod
    def _find_first(root: Path, names: List[str]):
        lower_names = {n.lower() for n in names}
        for p in root.rglob('*'):
            if p.is_file() and p.name.lower() in lower_names:
                return p
        return None

    def _write_manifest(self, path: Path, project_name: str, mode: str, outputs: Dict[str, str], load_flags: Dict):
        path.parent.mkdir(parents=True, exist_ok=True)
        data = {
            'plugin': 'GeoTivity Drone Tools',
            'version': '0.4.2-beta',
            'project_name': project_name,
            'mode': mode,
            'task_uuid': self._task_uuid,
            'created_at': now_text(),
            'outputs': outputs,
            'load_flags': load_flags,
        }
        path.write_text(json.dumps(data, ensure_ascii=False, indent=2), encoding='utf-8')

    def _write_log(self, path: Path):
        path.parent.mkdir(parents=True, exist_ok=True)
        path.write_text('\n'.join(self._log_lines) + '\n', encoding='utf-8')
