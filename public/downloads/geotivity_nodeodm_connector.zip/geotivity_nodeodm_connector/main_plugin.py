# -*- coding: utf-8 -*-

from qgis.PyQt.QtCore import Qt
from qgis.PyQt.QtWidgets import QAction
from qgis.core import Qgis

from .dock_widget import NodeODMDockWidget


class GeoTivityNodeODMConnector:
    def __init__(self, iface):
        self.iface = iface
        self.action = None
        self.dock = None

    def initGui(self):
        self.action = QAction('GeoTivity Drone Tools', self.iface.mainWindow())
        self.action.setObjectName('geotivity_nodeodm_connector_action')
        self.action.setToolTip('QGISからNodeODMを操作します')
        self.action.triggered.connect(self.show_dock)
        self.iface.addPluginToMenu('&GeoTivity Drone Tools', self.action)
        self.iface.addToolBarIcon(self.action)

    def unload(self):
        if self.action:
            self.iface.removePluginMenu('&GeoTivity Drone Tools', self.action)
            self.iface.removeToolBarIcon(self.action)
            self.action = None
        if self.dock:
            self.iface.removeDockWidget(self.dock)
            self.dock = None

    def show_dock(self):
        if self.dock is None:
            self.dock = NodeODMDockWidget(self.iface)
            self.iface.addDockWidget(Qt.RightDockWidgetArea, self.dock)
        self.dock.show()
        self.dock.raise_()
        self.iface.messageBar().pushMessage(
            'GeoTivity Drone Tools',
            'NodeODM接続URLと画像フォルダを指定してください。',
            level=Qgis.Info,
            duration=4,
        )
