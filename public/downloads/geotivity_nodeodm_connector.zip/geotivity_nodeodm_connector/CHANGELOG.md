# Changelog

## 0.4.2-beta - 2026-06-05

### Fixed

- ReadyCheckerの寿命問題を修正
  - `ready.connect(ready_thread.quit)` を追加してシグナル経由でスレッドを終了
  - `_on_nodeodm_ready` 内の手動 `quit()` 呼び出しを削除（二重呼び出し防止）
  - `_cleanup_ready_thread` の `deleteLater` 順序を修正（checker → thread の順）
- `_cleanup_env_thread` / `_cleanup_thread` に `deleteLater` を追加（GC安全化）

### Changed

- README に必要ライブラリ（requests）・Docker操作一覧・β版表記を追加

## 0.4.2 - 2026-06-05

### Fixed

- docker pull進捗通知を `finished` から専用 `progress` シグナルへ分離（スレッド終了タイミングの安定化）
- GPU版NodeODMイメージの導入判定を追加（CPU版のみ確認していた問題を修正）
- 接続エラーパターンのtypo修正（`nodeodh` → `nodeodm`）

### Changed

- README をv0.4.2向けに全面更新

## 0.4.1 - 2026-06-05

### Added

- セットアップウィザード追加
  - Docker未導入 → インストールページをブラウザで開くボタン
  - Docker停止中 → OS別の起動方法を表示（Windows/Mac/Linux対応）
  - NodeODM未導入 → 「NodeODMを導入する」ボタン（docker pull を実行、進捗表示）
  - 導入完了後 → 自動的に通常操作パネルへ切替
- `docker_manager.py` に `docker_install_url()` / `docker_start_guide()` / `image_exists()` / `pull_image()` を追加

### Changed

- 環境診断結果に応じてウィザードパネルを自動切替（未導入/停止中/OK を自動判定）
- NodeODM未起動時、イメージ有無を確認してウィザード or 起動ボタンを振り分け

## 0.4.0 - 2026-06-05

### Changed

- UIをステップ型（① 環境確認 → ② 写真選択 → ③ プリセット → ④ 実行）に全面刷新
- 技術用語（Docker・コンテナ・ポート番号）をユーザー向け日本語に変換
- エラーメッセージを分かりやすい日本語に自動変換（`_friendly_error`）
- 起動時に環境を自動診断し、次のアクションをガイドメッセージで案内
- NodeODM起動後の自動Ready確認をステップ遷移に統合

### Added

- プリセット4種を追加：🌲 森林 / 📐 測量 / 🌾 農業 / ⚡ 高速
- 写真枚数・容量をフォルダ選択直後に表示（20枚未満は警告）
- ステップインジケーター（Docker確認 → NodeODM確認 → 写真選択 → 解析実行 → 完了）
- NodeODM接続URL等の詳細設定を折りたたみに変更（デフォルト非表示）

## 0.3.1 - 2026-06-05

### Fixed

- Docker診断機能の安定化（`stop_result`未使用バグ修正）
- NodeODM接続処理のデバッグ修正
- DSM/DTM/CHM取得処理の修正
- GeoTivity for QGISとの役割整理
- サブフォルダ内画像の取得漏れ修正（`iterdir` → `rglob`）
- コンテナRunning判定ロジックの修正
- 「全部」プリセット選択時のモード誤設定修正（`forest` → `chm`）
- アップロードタイムアウトをファイルサイズ連動に変更

### Added

- NodeODM起動後の自動Ready確認（`/info`エンドポイントへポーリング）
- NodeODM Ready表示（接続確認を起動ボタンから自動実行）

### Changed

- プラグイン名称を `GeoTivity Drone Tools` に統一
- `experimental=False` に変更（公開候補）
- `icon=icon.png` を設定

## 0.3.0 - 2026-06-05

### Added

- 環境診断に空き容量とポート3000確認を追加
- CPU版/GPU版のPowerShellセットアップ手順コピー機能を追加
- 診断情報にPCリソース確認結果を追加
- UI文言を「解析はGeoTivity for QGISで実行する」切り分けに合わせて更新

### Changed

- Drone Tools側はODM処理・成果物整理・QGIS読込までを担当する位置づけに整理

## 0.2.0 - 2026-06-05

### Added

- プラグイン名称を `GeoTivity Drone Tools / NodeODM` に更新
- 成果物プリセットを追加
  - オルソのみ
  - DSM/DTM/CHM
  - 全部
- `CHM作成優先（DSM/DTM高精細）` モードを追加
- CHM作成時のDSM/DTM選択チェックを追加
- 実行設定と成果物一覧を `geotivity_nodeodm_manifest.json` に保存

### Changed

- UI文言をv0.2ロードマップに合わせて整理
- READMEをv0.2.0向けに更新
- metadataの説明・タグ・バージョンを更新

## 0.1.2 - 2026-06-05

### Added

- GPU診断ボタンを追加
- 診断情報コピー機能を追加
- README / CHANGELOG / LICENSE を追加

### Changed

- CPU版/GPU版の切替時に既存コンテナのイメージ差分を検出し、必要に応じて作り直すよう改善
- NodeODM成果物ZIPの安全解凍処理を追加
- 停止済み/未作成コンテナに対する停止処理のメッセージを改善

## 0.1.1

### Added

- NodeODM接続
- 画像アップロード
- ODM処理実行
- 成果物ダウンロード
- QGIS読込
- CHM作成
