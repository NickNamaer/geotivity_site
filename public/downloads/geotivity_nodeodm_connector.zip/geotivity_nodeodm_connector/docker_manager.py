# -*- coding: utf-8 -*-

import json
import os
import platform
import shutil
import socket
import subprocess
from dataclasses import dataclass
from typing import Tuple


CONTAINER_NAME = 'geotivity-nodeodm'
CPU_IMAGE = 'opendronemap/nodeodm'
GPU_IMAGE = 'opendronemap/nodeodm:gpu'


@dataclass
class CommandResult:
    ok: bool
    stdout: str = ''
    stderr: str = ''
    code: int = 0


def _run(args, timeout=20, env=None) -> CommandResult:
    try:
        completed = subprocess.run(
            args,
            stdout=subprocess.PIPE,
            stderr=subprocess.PIPE,
            text=True,
            encoding='utf-8',
            errors='replace',
            timeout=timeout,
            shell=False,
            env=env,
        )
        return CommandResult(
            ok=completed.returncode == 0,
            stdout=(completed.stdout or '').strip(),
            stderr=(completed.stderr or '').strip(),
            code=completed.returncode,
        )
    except FileNotFoundError as exc:
        return CommandResult(False, '', str(exc), 127)
    except subprocess.TimeoutExpired as exc:
        return CommandResult(False, exc.stdout or '', f'timeout: {exc}', 124)
    except Exception as exc:
        return CommandResult(False, '', str(exc), 1)


def _find_docker_executable():
    """
    dockerコマンドのフルパスを返す。
    shutil.which が失敗する場合（QGISのPATH環境変数の問題）に備え、
    Windowsの既定インストールパスも直接確認する。
    """
    found = shutil.which('docker')
    if found:
        return found
    if platform.system() == 'Windows':
        candidates = [
            r'C:\Program Files\Docker\Docker\resources\bin\docker.exe',
            r'C:\ProgramData\DockerDesktop\version-bin\docker.exe',
        ]
        for path in candidates:
            if os.path.isfile(path):
                return path
    return None


def _apply_safe_docker_env_globally():
    """
    モジュールロード時に一度だけ呼び出す。
    DOCKER_HOST を Windows Docker Desktop の名前付きパイプに固定することで、
    - docker context "desktop-linux" の解決エラー
    - docker-credential-desktop が QGISのPATHで見つからないエラー
    を両方回避する。
    """
    if platform.system() != 'Windows':
        return
    if os.environ.get('DOCKER_HOST'):
        return
    # Windows Docker Desktop の名前付きパイプを直接指定
    os.environ['DOCKER_HOST'] = 'npipe:////./pipe/docker_engine'


def _docker(*args, timeout=20) -> 'CommandResult':
    """dockerコマンドを実行する。PATHが通っていない・credsStore問題がある環境でも動作する。"""
    import tempfile
    exe = _find_docker_executable() or 'docker'
    env = os.environ.copy()
    tmp_dir = None
    try:
        orig_cfg_path = os.path.join(os.path.expanduser('~'), '.docker', 'config.json')
        with open(orig_cfg_path, 'r', encoding='utf-8') as f:
            cfg = json.load(f)
        if 'credsStore' in cfg or 'credHelpers' in cfg:
            safe_cfg = {k: v for k, v in cfg.items() if k not in ('credsStore', 'credHelpers')}
            tmp_dir = tempfile.mkdtemp(prefix='geotivity_docker_')
            with open(os.path.join(tmp_dir, 'config.json'), 'w', encoding='utf-8') as f:
                json.dump(safe_cfg, f)
            env['DOCKER_CONFIG'] = tmp_dir
    except Exception:
        pass
    try:
        return _run([exe, *args], timeout=timeout, env=env)
    finally:
        if tmp_dir:
            shutil.rmtree(tmp_dir, ignore_errors=True)


def docker_available() -> Tuple[bool, str]:
    exe = _find_docker_executable()
    if exe is None:
        return False, 'docker コマンドが見つかりません。Docker Desktopをインストールしてください。'
    result = _run([exe, '--version'], timeout=10)
    return result.ok, result.stdout or result.stderr


def docker_running() -> Tuple[bool, str]:
    # `docker info` はソケット接続が必要で環境によって失敗しやすいため
    # より軽量な `docker ps` で動作確認する（接続できればDaemon起動中）
    result = _docker('ps', '--format', '{{.Names}}', timeout=15)
    if result.ok:
        return True, 'Docker Daemon 起動中'
    # フォールバック: docker info も試みる
    result2 = _docker('info', '--format', '{{.ServerVersion}}', timeout=15)
    if result2.ok:
        return True, result2.stdout.strip()
    return False, result.stderr or result.stdout or 'Docker Desktopが起動していません。'


def container_status() -> Tuple[bool, str]:
    result = _docker(
        'ps', '-a',
        '--filter', f'name=^{CONTAINER_NAME}$',
        '--format', '{{.Names}}\t{{.Status}}\t{{.Image}}',
        timeout=10,
    )
    if not result.ok:
        return False, result.stderr or result.stdout
    if not result.stdout:
        return False, 'NodeODMコンテナは未作成です。'
    line = result.stdout.splitlines()[0]
    running = '\tUp ' in line
    return running, line





def system_resource_summary(port=3000) -> Tuple[bool, str]:
    """Return a lightweight preflight summary for ordinary field users."""
    messages = []
    ok = True
    try:
        usage = shutil.disk_usage('.')
        free_gb = usage.free / (1024 ** 3)
        messages.append(f'空き容量: {free_gb:.1f} GB')
        if free_gb < 50:
            ok = False
            messages.append('警告: ODM処理には50GB以上の空き容量を推奨します。')
    except Exception as exc:
        ok = False
        messages.append(f'空き容量確認失敗: {exc}')
    try:
        with socket.socket(socket.AF_INET, socket.SOCK_STREAM) as sock:
            sock.settimeout(1)
            used = sock.connect_ex(('127.0.0.1', int(port))) == 0
        messages.append(f'ポート{port}: ' + ('使用中' if used else '未使用'))
    except Exception as exc:
        ok = False
        messages.append(f'ポート確認失敗: {exc}')
    return ok, ' / '.join(messages)


def nodeodm_setup_powershell(gpu=False, port=3000) -> str:
    image = GPU_IMAGE if gpu else CPU_IMAGE
    gpu_arg = ' --gpus all' if gpu else ''
    return '\n'.join([
        '# GeoTivity Drone Tools / NodeODM setup',
        '# 1) Docker Desktopを起動してから実行してください。',
        'docker --version',
        'docker info',
        f'docker pull {image}',
        f'docker rm -f {CONTAINER_NAME} 2>$null',
        f'docker run -d --name {CONTAINER_NAME} -p {port}:3000 --restart unless-stopped{gpu_arg} {image}',
        f'Start-Process "http://localhost:{port}"',
    ])

DOCKER_INSTALL_URL = 'https://www.docker.com/products/docker-desktop/'


def docker_install_url() -> str:
    """OS別のDocker Desktop インストールページURLを返す。"""
    return DOCKER_INSTALL_URL


def docker_start_guide() -> str:
    """Docker Desktopの起動方法をOS別に返す。"""
    system = platform.system()
    if system == 'Windows':
        return (
            'Docker Desktopの起動方法（Windows）\n\n'
            '1. スタートメニューから「Docker Desktop」を検索して起動\n'
            '2. タスクトレイにクジラのアイコンが表示されるまで待つ\n'
            '3. アイコンが緑色になったら起動完了\n'
            '4. 「もう一度確認」を押してください'
        )
    elif system == 'Darwin':
        return (
            'Docker Desktopの起動方法（Mac）\n\n'
            '1. アプリケーションフォルダから「Docker」を起動\n'
            '2. メニューバーにクジラのアイコンが表示されるまで待つ\n'
            '3. アイコンが止まったら起動完了\n'
            '4. 「もう一度確認」を押してください'
        )
    else:
        return (
            'Docker Desktopの起動方法（Linux）\n\n'
            '1. ターミナルで以下を実行してください:\n'
            '   sudo systemctl start docker\n'
            '2. 「もう一度確認」を押してください'
        )


def image_exists(gpu=False) -> Tuple[bool, str]:
    """NodeODMのDockerイメージがローカルに存在するか確認する。"""
    image = GPU_IMAGE if gpu else CPU_IMAGE
    result = _docker('image', 'inspect', image, '--format', '{{.Id}}', timeout=10)
    if result.ok and result.stdout:
        return True, image
    return False, f'イメージ未取得: {image}'


def pull_image(gpu=False, progress_callback=None) -> Tuple[bool, str]:
    """NodeODMイメージをdocker pullで取得する。進捗はprogress_callbackで通知。"""
    import tempfile
    image = GPU_IMAGE if gpu else CPU_IMAGE
    exe = _find_docker_executable() or 'docker'

    # DOCKER_HOSTはos.environから引き継がれるが、
    # docker pullはDocker Hubの認証で credsStore を呼ぶため
    # credsStore/credHelpers を除いた config.json を一時ディレクトリに置く。
    # DOCKER_HOST設定済みなので contexts/ は不要。
    env = os.environ.copy()
    try:
        orig_cfg_path = os.path.join(os.path.expanduser('~'), '.docker', 'config.json')
        with open(orig_cfg_path, 'r', encoding='utf-8') as f:
            cfg = json.load(f)
    except Exception:
        cfg = {}
    safe_cfg = {k: v for k, v in cfg.items() if k not in ('credsStore', 'credHelpers')}
    tmp_dir = tempfile.mkdtemp(prefix='geotivity_pull_')
    try:
        with open(os.path.join(tmp_dir, 'config.json'), 'w', encoding='utf-8') as f:
            json.dump(safe_cfg, f)
        env['DOCKER_CONFIG'] = tmp_dir

        proc = subprocess.Popen(
            [exe, 'pull', image],
            stdout=subprocess.PIPE,
            stderr=subprocess.STDOUT,
            text=True,
            encoding='utf-8',
            errors='replace',
            env=env,
        )
        lines = []
        for line in proc.stdout:
            line = line.rstrip()
            lines.append(line)
            if progress_callback:
                progress_callback(line)
        proc.wait()
        if proc.returncode == 0:
            return True, f'{image} の取得が完了しました。'
        return False, '\n'.join(lines[-5:]) or 'docker pull に失敗しました。'
    except FileNotFoundError:
        return False, 'docker コマンドが見つかりません。'
    except Exception as exc:
        return False, str(exc)
    finally:
        shutil.rmtree(tmp_dir, ignore_errors=True)


def container_image() -> Tuple[bool, str]:
    result = _run([
        'docker', 'inspect', CONTAINER_NAME,
        '--format', '{{.Config.Image}}',
    ], timeout=10)
    if result.ok and result.stdout:
        return True, result.stdout.strip()
    return False, result.stderr or result.stdout or 'コンテナイメージを取得できません。'

def start_nodeodm(gpu=False, port=3000) -> Tuple[bool, str]:
    image = GPU_IMAGE if gpu else CPU_IMAGE
    # Existing container can be restarted if it uses the same intended image.
    # If CPU/GPU mode changed, recreate the container so the button does what it says.
    status_result = _docker('ps', '-a', '--filter', f'name=^{CONTAINER_NAME}$', '--format', '{{.Names}}', timeout=10)
    if status_result.ok and CONTAINER_NAME in status_result.stdout.splitlines():
        image_ok, current_image = container_image()
        if image_ok and current_image == image:
            started = _docker('start', CONTAINER_NAME, timeout=30)
            if started.ok:
                return True, f'既存コンテナを起動しました: {CONTAINER_NAME} ({image})'
            return False, started.stderr or started.stdout
        stop_result = _docker('stop', CONTAINER_NAME, timeout=30)
        if not stop_result.ok and 'is not running' not in (stop_result.stderr + stop_result.stdout).lower():
            return False, stop_result.stderr or stop_result.stdout or '既存コンテナの停止に失敗しました。'
        rm_result = _docker('rm', CONTAINER_NAME, timeout=30)
        if not rm_result.ok:
            return False, rm_result.stderr or rm_result.stdout or '既存コンテナの削除に失敗しました。'

    run_args = [
        'run', '-d',
        '--name', CONTAINER_NAME,
        '-p', f'{port}:3000',
        '--restart', 'unless-stopped',
    ]
    if gpu:
        run_args.extend(['--gpus', 'all'])
    run_args.append(image)
    result = _docker(*run_args, timeout=120)
    if result.ok:
        return True, f'NodeODMを起動しました: {image}'
    return False, result.stderr or result.stdout


def stop_nodeodm() -> Tuple[bool, str]:
    exists = _docker('ps', '-a', '--filter', f'name=^{CONTAINER_NAME}$', '--format', '{{.Names}}', timeout=10)
    if exists.ok and CONTAINER_NAME not in exists.stdout.splitlines():
        return True, 'NodeODMコンテナは未作成です。'
    result = _docker('stop', CONTAINER_NAME, timeout=30)
    if result.ok:
        return True, f'NodeODMを停止しました: {CONTAINER_NAME}'
    if 'is not running' in (result.stderr or result.stdout).lower():
        return True, f'NodeODMコンテナは既に停止しています: {CONTAINER_NAME}'
    return False, result.stderr or result.stdout


def gpu_available_hint() -> Tuple[bool, str]:
    # This confirms Docker can see a GPU. It may pull/use a lightweight CUDA image, so keep it optional-ish.
    result = _docker('run', '--rm', '--gpus', 'all', 'nvidia/cuda:12.4.1-base-ubuntu22.04', 'nvidia-smi', '--query-gpu=name', '--format=csv,noheader', timeout=90)
    if result.ok:
        return True, result.stdout
    return False, result.stderr or result.stdout or 'GPU確認に失敗しました。NVIDIA Driver / Docker GPU設定を確認してください。'


def diagnostic_report(nodeodm_url='http://localhost:3000', nodeodm_info=None) -> str:
    docker_ok, docker_msg = docker_available()
    running_ok, running_msg = docker_running() if docker_ok else (False, '-')
    node_running, node_msg = container_status() if docker_ok and running_ok else (False, '-')
    resource_ok, resource_msg = system_resource_summary()
    lines = [
        'GeoTivity NodeODM Connector Diagnostic',
        '',
        f'OS: {platform.platform()}',
        f'Python: {platform.python_version()}',
        f'NodeODM URL: {nodeodm_url}',
        f'Docker command: {"OK" if docker_ok else "NG"} / {docker_msg}',
        f'Docker running: {"OK" if running_ok else "NG"} / {running_msg}',
        f'NodeODM container: {"Running" if node_running else "Not running"} / {node_msg}',
        f'System resources: {"OK" if resource_ok else "WARN"} / {resource_msg}',
    ]
    if nodeodm_info is not None:
        try:
            info_text = json.dumps(nodeodm_info, ensure_ascii=False, indent=2)
        except Exception:
            info_text = str(nodeodm_info)
        lines.extend(['', 'NodeODM /info:', info_text])
    return '\n'.join(lines)


# モジュールロード時にcredsStore問題を一度だけ解消する
_apply_safe_docker_env_globally()

