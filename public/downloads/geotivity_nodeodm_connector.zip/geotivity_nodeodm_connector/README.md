# GeoTivity Drone Tools

ドローン写真からQGIS森林解析へ到達するための、QGISプラグインです。

> **GeoTivity Drone Tools v0.4.2-beta**
>
> このプラグインはNodeODMを利用してドローン写真からオルソ画像・DSM・DTM等を生成するための QGIS 用補助ツールです。
> 現在はβ版です。本番利用前に必ずテストデータで動作を確認してください。


## v0.4.2 の位置づけ

GeoTivity Drone Tools は「ODMを操作するソフト」ではなく、  
**「ドローン写真をQGIS解析へ繋ぐための入口」** です。

ユーザーはDockerやNodeODMの知識なしに、写真フォルダを選ぶだけで  
オルソ画像・DSM・DTM・CHMを生成し、QGISで森林解析を開始できます。

### 製品の役割分担

| 製品 | 担当 |
|------|------|
| **GeoTivity Drone Tools**（本プラグイン） | 環境診断・NodeODM管理・ODM処理・DSM/DTM/CHM生成・QGIS読込 |
| **GeoTivity for QGIS** | 樹頂点抽出・樹冠ポリゴン・材積推定・森林簿連携・Jクレジット支援 |

---

## v0.4.2 追加機能

- **セットアップウィザード**
  - Docker未導入 → インストールページをブラウザで開く
  - Docker停止中 → OS別の起動方法を案内（Windows / Mac / Linux）
  - NodeODM未導入 → 「導入する」ボタンで `docker pull` を自動実行
- **ステップ型UI** — 「次に何をすべきか」を常にガイド
- **プリセット4種** — 🌲 森林 / 📐 測量 / 🌾 農業 / ⚡ 高速
- **エラーメッセージの日本語化** — 技術的なエラーを分かりやすく変換

---

## 対応環境

- QGIS 3.40 以上
- Windows 11 / Windows 10 / macOS / Ubuntu
- Docker Desktop または Docker Engine
- NodeODM CPU版 または GPU版

## 必要ライブラリ

本プラグインは以下のPythonライブラリを使用します。

| ライブラリ | 用途 |
|-----------|------|
| `requests` | NodeODM APIとのHTTP通信 |

QGISに同梱されていない場合は、OSGeo4W Shell（Windows）またはターミナルから以下を実行してください。

```bash
pip install requests
```

## Docker操作について

本プラグインは、NodeODMコンテナを管理するために以下のDockerコマンドを実行します。

```bash
docker pull opendronemap/nodeodm     # NodeODMイメージの取得
docker run  ...                      # コンテナの作成・起動
docker start geotivity-nodeodm      # 既存コンテナの起動
docker stop  geotivity-nodeodm      # コンテナの停止
docker rm    geotivity-nodeodm      # コンテナの削除（CPU/GPU切替時）
```

作成されるコンテナ名は `geotivity-nodeodm` です。  
既存の同名コンテナがある場合、CPU/GPU切替時は自動で削除・再作成します。

---

## v0.4.2 主な更新

- セットアップウィザード（Docker未導入・停止・NodeODM未導入の3状態に対応）
- docker pull 進捗通知のシグナル分離によるスレッド安定化
- GPU版NodeODMイメージの導入判定を改善
- 接続エラーパターンのtypo修正（nodeodh → nodeodm）
- ステップ型UI全面刷新（v0.4.0〜）
- 起動時の自動環境診断
- NodeODM起動後の自動Ready確認（/infoポーリング）

---

## インストール方法

1. ZIPを解凍します。
2. `geotivity_nodeodm_connector` フォルダをQGISのプラグインフォルダへ配置します。
   - Windows: `%APPDATA%\QGIS\QGIS3\profiles\default\python\plugins\`
   - Mac: `~/Library/Application Support/QGIS/QGIS3/profiles/default/python/plugins/`
3. QGISを再起動します。
4. プラグインマネージャから `GeoTivity Drone Tools` を有効化します。

---

## 使い方（通常利用）

### 初回のみ

1. QGISでプラグインを開く
2. 「環境確認」パネルの案内に従いDocker・NodeODMを導入
3. 「NodeODM 起動」を押す → 自動でReady確認

### 毎回の操作

1. QGIS起動 → GeoTivity Drone Toolsを開く
2. 写真フォルダを選択
3. 出力フォルダを選択
4. プリセットを選択（森林 / 測量 / 農業 / 高速）
5. 「▶ 解析開始」を押す
6. 完了後、成果物がQGISに自動読み込み

---

## v0.4.2 推奨操作

森林解析（GeoTivity for QGIS連携）の場合:

1. プリセット: **🌲 森林（DSM・DTM・CHM作成）**
2. そのまま「▶ 解析開始」
3. 完了後、GeoTivity for QGISで解析を実行

---

## 出力構成

```text
出力フォルダ/
└─ プロジェクト名/
   ├─ orthophoto/
   │  └─ orthophoto.tif
   ├─ elevation/
   │  ├─ dsm.tif
   │  ├─ dtm.tif
   │  └─ chm.tif
   ├─ pointcloud/
   │  └─ pointcloud.laz（またはpointcloud.las）
   ├─ logs/
   │  └─ process_log.txt
   ├─ geotivity_nodeodm_manifest.json
   └─ _nodeodm_raw/
      ├─ all.zip
      └─ extracted/
```
---

## 依存ライブラリ

本プラグインは以下のPythonライブラリを使用します。

| ライブラリ | 用途 | 備考 |
|-----------|------|------|
| `requests` | NodeODM APIとの通信 | QGISに同梱されていない環境では別途インストールが必要 |

QGISのデフォルト環境に `requests` が含まれていない場合は、  
OSGeo4W Shell（Windows）またはターミナルで以下を実行してください。

```bash
pip install requests
```

---

## 本プラグインが実行するDocker操作

本プラグインはNodeODMコンテナを管理するために、以下のDocker操作を自動的に実行します。

| 操作 | タイミング |
|------|-----------|
| `docker pull opendronemap/nodeodm` | 「NodeODMを導入する」ボタン押下時 |
| `docker run ...` | 「NodeODM 起動」ボタン押下時 |
| `docker start` | 既存コンテナの再起動時 |
| `docker stop` | 「停止」ボタン押下時 |
| `docker rm` | CPU/GPU切替でコンテナ再作成が必要な場合 |

コンテナ名は `geotivity-nodeodm` で作成されます。  
既存の同名コンテナがある場合は上書きされる場合があります。

---

## 注意事項

- NodeODM本体はこのプラグインに同梱されません。初回のみ導入が必要です。
- Docker DesktopまたはDocker Engineが必要です。
- ODM処理には50GB以上のディスク空き容量を推奨します。
- GPU版は環境依存が大きいため、まずCPU版で動作確認してください。
- CHMはDSMとDTMの差分（DSM − DTM、負値は0）で作成します。

---

## 今後の予定

### v0.5

- 成果物一覧・出力フォルダ管理
- GeoPackage出力
- レポート出力
- GeoTivity for QGIS連携強化

### v1.0

- 正式公開版
- 運用マニュアル同梱
- 公開リポジトリ対応

---

## 必要ライブラリ

本プラグインは以下のPythonライブラリを使用します。

| ライブラリ | 用途 |
|-----------|------|
| `requests` | NodeODM APIとの通信 |

QGISに同梱されていない場合は、OSGeo4W Shell（Windows）またはターミナルで以下を実行してください。

```bash
pip install requests
```

---

## Dockerコンテナについて

本プラグインは、NodeODMを動作させるために以下のDocker操作を自動で実行します。

| 操作 | タイミング |
|------|-----------|
| `docker pull opendronemap/nodeodm` | 初回導入時（NodeODM未導入の場合） |
| `docker run` | 「NodeODM 起動」ボタン押下時 |
| `docker start` | 既存コンテナの再起動時 |
| `docker stop` | 「停止」ボタン押下時 |
| `docker rm` | GPU/CPU切替時（コンテナ再作成のため） |

作成されるコンテナ名: `geotivity-nodeodm`

Docker Desktopから確認・削除が可能です。

---

## β版について

```
GeoTivity Drone Tools v0.4.2-beta

このプラグインはNodeODMを利用して
ドローン写真からオルソ画像・DSM・DTM等を生成するための
QGIS用補助ツールです。

現在はβ版です。
本番利用前に必ずテストデータで検証してください。
```
