# -*- coding: utf-8 -*-

import os
import re
import time
import platform
from datetime import datetime
from pathlib import Path

from qgis.PyQt.QtCore import QSettings, QThread, Qt, QObject, pyqtSignal, QTimer
from qgis.PyQt.QtGui import QTextCursor
from qgis.PyQt.QtWidgets import (
    QCheckBox,
    QComboBox,
    QDockWidget,
    QFileDialog,
    QFormLayout,
    QGroupBox,
    QHBoxLayout,
    QLabel,
    QLineEdit,
    QMessageBox,
    QPushButton,
    QProgressBar,
    QTextEdit,
    QVBoxLayout,
    QApplication,
    QWidget,
    QFrame,
    QScrollArea,

)
from qgis.core import QgsMessageLog, QgsPointCloudLayer, QgsProject, QgsRasterLayer, Qgis

try:
    from qgis.analysis import QgsRasterCalculator, QgsRasterCalculatorEntry
except Exception:
    QgsRasterCalculator = None
    QgsRasterCalculatorEntry = None

from .nodeodm_client import NodeODMClient
from .worker import ODMWorker
from . import docker_manager


SETTINGS_PREFIX = 'GeoTivity/DroneTools'

# ── エラーメッセージを日本語に変換 ─────────────────────────────
_ERROR_PATTERNS = [
    (r'docker.*not found|docker.*コマンドが見つかりません',
     'Docker Desktopがインストールされていません。\n'
     '「Docker Desktop インストールページを開く」から導入してください。'),
    (r'docker.*is not running|Docker Desktop.*起動していません',
     'Docker Desktopが起動していません。\n'
     '起動方法：タスクトレイ（またはアプリ一覧）から Docker Desktop を起動してください。'),
    (r'port.*already.*use|port.*3000.*conflict|address already in use',
     'ポート3000が他のアプリで使用されています。\n'
     '原因候補：\n'
     '・すでにNodeODMコンテナが起動中\n'
     '・別のアプリがポート3000を使用中\n'
     '→「停止」ボタンを押してから再度「NodeODM起動」を試してください。'),
    (r'connection.*refused|nodeodmに接続できません|cannot connect',
     'NodeODMに接続できませんでした。\n'
     '原因候補：\n'
     '・Docker Desktopが起動していない\n'
     '・NodeODMコンテナが起動していない\n'
     '・ポート3000が別のアプリで使用中\n'
     '→「もう一度確認」を押して環境を確認してください。'),
    (r'no.*image.*found|image.*not.*found',
     'NodeODMのイメージが見つかりません。\n'
     '→「NodeODMを導入する」ボタンでダウンロードしてください。'),
    (r'timeout',
     '処理がタイムアウトしました。\n'
     '原因候補：\n'
     '・ネットワーク接続が不安定\n'
     '・NodeODMの処理が重い\n'
     '・PCのリソース（メモリ・CPU）が不足\n'
     '→ しばらく待ってから「もう一度確認」を押してください。'),
    (r'no space left|disk.*full',
     'ディスクの空き容量が不足しています。\n'
     '→ 不要なファイルを削除してから再試行してください。\n'
     '（ODM処理には50GB以上の空き容量を推奨します）'),
    (r'画像フォルダ内に.*見つかりません',
     '写真フォルダにJPEG/TIFFファイルが見つかりません。\n'
     '→ フォルダの中にドローン写真（.jpg/.tif）があるか確認してください。'),
    (r'ODM処理に失敗',
     'ODM処理でエラーが発生しました。\n'
     '原因候補：\n'
     '・写真枚数が少ない（20枚以上を推奨）\n'
     '・写真の重複が少なく点群を生成できない\n'
     '・PCのメモリ・ディスクが不足\n'
     '→ 写真枚数と撮影重複率（70%以上）を確認してください。'),
    (r'ユーザー操作により処理を中止',
     '処理を中止しました。'),
    (r'layer.*invalid|is not valid',
     '成果物ファイルの読み込みに失敗しました。\n'
     '出力フォルダにファイルが正しく生成されているか確認してください。'),
    (r'pdal|点群読込',
     '点群ファイルの読み込みに失敗しました。\n'
     '→ QGISのPDALプロバイダが有効か確認してください。'),
    (r'raster.*calculator|QgsRasterCalculator',
     'CHM作成に失敗しました。\n'
     '→ DSMとDTMのファイルが正しく生成されているか確認してください。'),
]

def _friendly_error(raw: str) -> str:
    low = raw.lower()
    for pattern, msg in _ERROR_PATTERNS:
        if re.search(pattern, low):
            return msg
    # マッチしない場合も原因候補を付記して返す
    return (
        f'{raw}\n\n'
        '解決しない場合は「診断情報をコピー」からサポートへお問い合わせください。'
    )


# 原因候補のヒントを返す（エラーダイアログの補足として表示）
_HINT_PATTERNS = [
    (
        r'connection.*refused|cannot connect|nodeodmに接続',
        '原因として考えられること：\n'
        '・Docker Desktopが起動していない\n'
        '・NodeODMコンテナが起動していない\n'
        '・ポート3000が他のアプリで使用中\n\n'
        '「① 環境確認」→「もう一度確認」で状態を確認してください。',
    ),
    (
        r'no space left|disk.*full|空き容量',
        '対処方法：\n'
        '・不要なファイルを削除して空き容量を確保してください\n'
        '・ODM処理には50GB以上の空き容量を推奨します。',
    ),
    (
        r'ODM処理に失敗|odm.*fail',
        '原因として考えられること：\n'
        '・画像枚数が少ない（20枚以上を推奨）\n'
        '・画像に位置情報（GPS）が含まれていない\n'
        '・隣接率が低い（70%以上の重複を推奨）',
    ),
    (
        r'timeout',
        '対処方法：\n'
        '・ネットワーク接続を確認してください\n'
        '・NodeODMが処理中の場合、しばらく待ってから再試行してください。',
    ),
    (
        r'画像フォルダ内に.*見つかりません',
        '対処方法：\n'
        '・JPEG（.jpg/.jpeg）またはTIFF（.tif/.tiff）が含まれているか確認してください\n'
        '・サブフォルダ内の画像も自動的に検索します。',
    ),
]

def _error_hint(raw: str) -> str:
    """エラーに対応した原因候補ヒントを返す。該当なしは空文字。"""
    low = raw.lower()
    for pattern, hint in _HINT_PATTERNS:
        if re.search(pattern, low):
            return hint
    return ''

# ── ステップ状態管理 ────────────────────────────────────────
STEP_DOCKER  = 0
STEP_NODEODM = 1
STEP_PHOTOS  = 2
STEP_RUN     = 3
STEP_DONE    = 4

STEP_LABELS = ['Docker確認', 'NodeODM確認', '写真選択', '解析実行', '完了']


# ── バックグラウンドワーカー（環境操作） ─────────────────────
class EnvWorker(QObject):
    finished = pyqtSignal(str, bool, str)   # action, ok, message
    progress = pyqtSignal(str, str)         # action, message（進捗通知専用）

    def __init__(self, action, url='http://localhost:3000'):
        super().__init__()
        self.action = action
        self.url = url

    def run(self):
        try:
            a = self.action
            if a == 'diagnose':
                docker_ok, docker_msg = docker_manager.docker_available()
                # docker_available失敗でも docker_running を試みる
                # （QGISのPATH問題で --version は失敗するが ps は成功するケースがある）
                if docker_ok:
                    running_ok, running_msg = docker_manager.docker_running()
                else:
                    running_ok, running_msg = docker_manager.docker_running()
                    if running_ok:
                        # docker_running が成功したなら Docker自体はある
                        docker_ok = True
                        docker_msg = 'Docker Desktop（コマンド検出方法を調整しました）'
                node_ok, node_msg = docker_manager.container_status() if running_ok else (False, '-')
                resource_ok, resource_msg = docker_manager.system_resource_summary()
                lines = [
                    f'Docker Desktop: {"✓" if docker_ok else "✗"} {docker_msg}',
                    f'Docker起動: {"✓" if running_ok else "✗"} {running_msg}',
                    f'NodeODMコンテナ: {"✓ 起動中" if node_ok else "✗ 未起動"} {node_msg}',
                    f'ディスク: {"✓" if resource_ok else "⚠"} {resource_msg}',
                ]
                overall = docker_ok and running_ok and node_ok and resource_ok
                self.finished.emit(a, overall, '\n'.join(lines))
            elif a == 'start':
                ok, msg = docker_manager.start_nodeodm(gpu=False)
                self.finished.emit(a, ok, msg)
            elif a == 'start_gpu':
                ok, msg = docker_manager.start_nodeodm(gpu=True)
                self.finished.emit(a, ok, msg)
            elif a == 'stop':
                ok, msg = docker_manager.stop_nodeodm()
                self.finished.emit(a, ok, msg)
            elif a in ('pull', 'pull_gpu'):
                gpu = (a == 'pull_gpu')
                def cb(line):
                    self.progress.emit('pull_progress', line)
                ok, msg = docker_manager.pull_image(gpu=gpu, progress_callback=cb)
                self.finished.emit(a, ok, msg)
            elif a == 'check_gpu':
                ok, msg = docker_manager.gpu_available_hint()
                self.finished.emit(a, ok, msg)
            elif a == 'report':
                try:
                    info = NodeODMClient(self.url, timeout=5).test_connection()
                except Exception as exc:
                    info = {'connection_error': str(exc)}
                self.finished.emit(a, True, docker_manager.diagnostic_report(self.url, info))
            elif a == 'setup_cpu':
                self.finished.emit(a, True, docker_manager.nodeodm_setup_powershell(gpu=False))
            elif a == 'setup_gpu':
                self.finished.emit(a, True, docker_manager.nodeodm_setup_powershell(gpu=True))
            else:
                self.finished.emit(a, False, f'未対応の操作: {a}')
        except Exception as exc:
            self.finished.emit(self.action, False, str(exc))


# ── メインウィジェット ──────────────────────────────────────
class NodeODMDockWidget(QDockWidget):
    def __init__(self, iface):
        super().__init__('GeoTivity Drone Tools')
        self.iface = iface
        self.settings = QSettings()
        self.thread = None
        self.worker = None
        self.env_thread = None
        self.env_worker = None
        self.ready_thread = None
        self.ready_checker = None
        self.is_running = False
        self.started_at = None
        self._current_step = STEP_DOCKER
        self._build_ui()
        self._load_settings()
        # 起動時に環境を自動診断
        QTimer.singleShot(500, self._auto_diagnose)

    # ══════════════════════════════════════════════════════
    # UI構築
    # ══════════════════════════════════════════════════════
    def _build_ui(self):
        root = QWidget()
        layout = QVBoxLayout(root)
        layout.setSpacing(8)

        # ── ステップインジケーター ──
        step_frame = QFrame()
        step_frame.setFrameShape(QFrame.StyledPanel)
        step_layout = QHBoxLayout(step_frame)
        step_layout.setContentsMargins(6, 4, 6, 4)
        self._step_labels = []
        for i, label in enumerate(STEP_LABELS):
            lbl = QLabel(label)
            lbl.setAlignment(Qt.AlignCenter)
            lbl.setMinimumWidth(60)
            self._step_labels.append(lbl)
            step_layout.addWidget(lbl)
            if i < len(STEP_LABELS) - 1:
                arrow = QLabel('→')
                arrow.setAlignment(Qt.AlignCenter)
                step_layout.addWidget(arrow)
        layout.addWidget(step_frame)

        # ── ガイドメッセージ ──
        self.guide_label = QLabel('環境を確認しています...')
        self.guide_label.setWordWrap(True)
        self.guide_label.setStyleSheet('font-weight: bold; padding: 4px;')
        layout.addWidget(self.guide_label)

        # ══ STEP 0: 環境確認 + セットアップウィザード ══
        self.step0_group = QGroupBox('① 環境確認')
        s0 = QVBoxLayout(self.step0_group)

        # ── 診断ステータス表示 ──
        self.env_status_label = QLabel('確認中...')
        self.env_status_label.setWordWrap(True)
        s0.addWidget(self.env_status_label)

        # ── ウィザードパネル（状態に応じて表示切替） ──

        # [A] Docker未導入パネル
        self.wizard_no_docker = QFrame()
        wa = QVBoxLayout(self.wizard_no_docker)
        wa.setContentsMargins(0, 0, 0, 0)
        lbl_a = QLabel('Docker Desktopがインストールされていません。\n以下のボタンからインストールページを開いてください。')
        lbl_a.setWordWrap(True)
        wa.addWidget(lbl_a)
        wa_row = QHBoxLayout()
        self.btn_open_docker_url = QPushButton('🌐  インストールページを開く')
        self.btn_open_docker_url.setStyleSheet('font-weight: bold; padding: 6px;')
        self.btn_open_docker_url.clicked.connect(self._open_docker_install_page)
        self.btn_diagnose_no_docker = QPushButton('🔄  もう一度確認')
        self.btn_diagnose_no_docker.setStyleSheet('font-weight: bold;')
        self.btn_diagnose_no_docker.clicked.connect(lambda: self._run_env('diagnose'))
        wa_row.addWidget(self.btn_open_docker_url, 2)
        wa_row.addWidget(self.btn_diagnose_no_docker, 1)
        wa.addLayout(wa_row)
        lbl_a2 = QLabel('インストール後、Docker Desktopを起動してから「もう一度確認」を押してください。')
        lbl_a2.setWordWrap(True)
        lbl_a2.setStyleSheet('color: #555; font-size: 10px;')
        wa.addWidget(lbl_a2)
        self.wizard_no_docker.setVisible(False)
        s0.addWidget(self.wizard_no_docker)

        # [B] Docker停止中パネル
        self.wizard_docker_stopped = QFrame()
        wb = QVBoxLayout(self.wizard_docker_stopped)
        wb.setContentsMargins(0, 0, 0, 0)
        lbl_b = QLabel('Docker Desktopが起動していません。')
        lbl_b.setWordWrap(True)
        wb.addWidget(lbl_b)
        wb_row = QHBoxLayout()
        self.btn_show_docker_guide = QPushButton('📋  起動方法を表示')
        self.btn_show_docker_guide.clicked.connect(self._show_docker_start_guide)
        self.btn_diagnose_stopped = QPushButton('🔄  もう一度確認')
        self.btn_diagnose_stopped.setStyleSheet('font-weight: bold;')
        self.btn_diagnose_stopped.clicked.connect(lambda: self._run_env('diagnose'))
        wb_row.addWidget(self.btn_show_docker_guide)
        wb_row.addWidget(self.btn_diagnose_stopped)
        wb.addLayout(wb_row)
        self.docker_guide_label = QLabel('')
        self.docker_guide_label.setWordWrap(True)
        self.docker_guide_label.setStyleSheet(
            'background: #f5f5f5; padding: 6px; border: 1px solid #ccc; font-size: 10px;'
        )
        self.docker_guide_label.setVisible(False)
        wb.addWidget(self.docker_guide_label)
        self.wizard_docker_stopped.setVisible(False)
        s0.addWidget(self.wizard_docker_stopped)

        # [C] NodeODM未導入パネル
        self.wizard_no_nodeodm = QFrame()
        wc = QVBoxLayout(self.wizard_no_nodeodm)
        wc.setContentsMargins(0, 0, 0, 0)
        lbl_c = QLabel('NodeODMがまだ導入されていません。\n以下のボタンで自動的にダウンロード・導入します（数分かかります）。')
        lbl_c.setWordWrap(True)
        wc.addWidget(lbl_c)
        pull_row = QHBoxLayout()
        self.btn_pull = QPushButton('⬇  NodeODM を導入する（CPU版）')
        self.btn_pull.setStyleSheet('font-weight: bold; padding: 6px;')
        self.btn_pull_gpu = QPushButton('⬇  GPU版')
        self.btn_pull.clicked.connect(lambda: self._run_env('pull'))
        self.btn_pull_gpu.clicked.connect(lambda: self._run_env('pull_gpu'))
        pull_row.addWidget(self.btn_pull, 3)
        pull_row.addWidget(self.btn_pull_gpu, 1)
        wc.addLayout(pull_row)
        self.pull_status_label = QLabel('')
        self.pull_status_label.setWordWrap(True)
        self.pull_status_label.setStyleSheet('font-size: 10px; color: #333;')
        self.pull_progress_bar = QProgressBar()
        self.pull_progress_bar.setMaximum(0)   # indeterminate
        self.pull_progress_bar.setMaximumHeight(8)
        self.pull_progress_bar.setTextVisible(False)
        self.pull_progress_bar.setVisible(False)
        wc.addWidget(self.pull_status_label)
        wc.addWidget(self.pull_progress_bar)
        self.btn_diagnose_no_nodeodm = QPushButton('🔄  もう一度確認')
        self.btn_diagnose_no_nodeodm.clicked.connect(lambda: self._run_env('diagnose'))
        wc.addWidget(self.btn_diagnose_no_nodeodm)
        self.wizard_no_nodeodm.setVisible(False)
        s0.addWidget(self.wizard_no_nodeodm)

        # ── 通常操作ボタン（NodeODM起動・停止など） ──
        self.wizard_normal = QFrame()
        wn = QVBoxLayout(self.wizard_normal)
        wn.setContentsMargins(0, 0, 0, 0)
        row0 = QHBoxLayout()
        self.btn_diagnose       = QPushButton('もう一度確認')
        self.btn_start_nodeodm  = QPushButton('NodeODM 起動')
        self.btn_start_gpu      = QPushButton('GPU版で起動')
        self.btn_stop           = QPushButton('停止')
        self.btn_diagnose.clicked.connect(lambda: self._run_env('diagnose'))
        self.btn_start_nodeodm.clicked.connect(lambda: self._run_env('start'))
        self.btn_start_gpu.clicked.connect(lambda: self._run_env('start_gpu'))
        self.btn_stop.clicked.connect(lambda: self._run_env('stop'))
        for b in (self.btn_diagnose, self.btn_start_nodeodm, self.btn_start_gpu, self.btn_stop):
            row0.addWidget(b)
        wn.addLayout(row0)
        row0b = QHBoxLayout()
        self.btn_setup_cpu  = QPushButton('導入手順コピー（CPU）')
        self.btn_setup_gpu  = QPushButton('導入手順コピー（GPU）')
        self.btn_diag_copy  = QPushButton('診断情報コピー')
        self.btn_setup_cpu.clicked.connect(lambda: self._run_env('setup_cpu'))
        self.btn_setup_gpu.clicked.connect(lambda: self._run_env('setup_gpu'))
        self.btn_diag_copy.clicked.connect(lambda: self._run_env('report'))
        for b in (self.btn_setup_cpu, self.btn_setup_gpu, self.btn_diag_copy):
            b.setStyleSheet('font-size: 10px;')
            row0b.addWidget(b)
        wn.addLayout(row0b)
        self.wizard_normal.setVisible(True)
        s0.addWidget(self.wizard_normal)

        layout.addWidget(self.step0_group)

        # ══ STEP 1: 接続確認（ユーザーには隠す、詳細設定として折りたたみ） ══
        self.step1_group = QGroupBox('② NodeODM接続（詳細設定）')
        self.step1_group.setCheckable(True)
        self.step1_group.setChecked(False)  # 初期は折りたたみ
        s1 = QVBoxLayout(self.step1_group)
        url_row = QHBoxLayout()
        self.url_edit = QLineEdit()
        self.url_edit.setPlaceholderText('http://localhost:3000')
        self.btn_test = QPushButton('接続テスト')
        self.btn_test.clicked.connect(self._test_connection)
        url_row.addWidget(QLabel('URL'))
        url_row.addWidget(self.url_edit, 1)
        url_row.addWidget(self.btn_test)
        s1.addLayout(url_row)
        self.connection_label = QLabel('')
        s1.addWidget(self.connection_label)
        layout.addWidget(self.step1_group)

        # ══ STEP 2: 写真・出力設定 ══
        self.step2_group = QGroupBox('② 写真・出力フォルダを選択')
        s2 = QFormLayout(self.step2_group)
        img_row = QHBoxLayout()
        self.image_folder_edit = QLineEdit()
        self.image_folder_edit.setPlaceholderText('ドローン写真が入ったフォルダ')
        btn_img = QPushButton('選択')
        btn_img.clicked.connect(self._select_image_folder)
        img_row.addWidget(self.image_folder_edit, 1)
        img_row.addWidget(btn_img)
        s2.addRow('写真フォルダ', img_row)
        self.photo_count_label = QLabel('')
        s2.addRow('', self.photo_count_label)

        out_row = QHBoxLayout()
        self.output_folder_edit = QLineEdit()
        self.output_folder_edit.setPlaceholderText('成果物の保存先フォルダ')
        btn_out = QPushButton('選択')
        btn_out.clicked.connect(self._select_output_folder)
        out_row.addWidget(self.output_folder_edit, 1)
        out_row.addWidget(btn_out)
        s2.addRow('出力フォルダ', out_row)

        self.project_name_edit = QLineEdit()
        self.project_name_edit.setPlaceholderText('未入力なら日時で自動生成')
        s2.addRow('プロジェクト名', self.project_name_edit)
        layout.addWidget(self.step2_group)

        # ══ STEP 3: プリセット選択 ══
        self.step3_group = QGroupBox('③ 解析プリセットを選択')
        s3 = QVBoxLayout(self.step3_group)

        self.preset_combo = QComboBox()
        presets = [
            ('🌲 森林（DSM・DTM・CHM作成）',    'forest'),
            ('📐 測量（高精細オルソ・DSM）',      'survey'),
            ('🌾 農業（オルソ・DSM）',            'agri'),
            ('⚡ 高速（オルソのみ・確認用）',      'fast'),
        ]
        for label, key in presets:
            self.preset_combo.addItem(label, key)
        self.preset_combo.currentIndexChanged.connect(self._on_preset_changed)
        s3.addWidget(self.preset_combo)

        self.preset_desc = QLabel()
        self.preset_desc.setWordWrap(True)
        self.preset_desc.setStyleSheet('color: #555; padding: 2px 4px;')
        s3.addWidget(self.preset_desc)

        # 詳細設定（折りたたみ）
        detail_group = QGroupBox('詳細設定（任意）')
        detail_group.setCheckable(True)
        detail_group.setChecked(False)
        sd = QVBoxLayout(detail_group)
        self.mode_combo = QComboBox()
        modes = [
            ('高速（簡易オルソ）',         'fast'),
            ('標準（通常業務）',           'standard'),
            ('高精細（高解像度）',         'high'),
            ('森林向け（DSM/DTM高精細）', 'forest'),
            ('CHM作成優先',              'chm'),
        ]
        for label, key in modes:
            self.mode_combo.addItem(label, key)
        sd.addWidget(QLabel('ODMモード（プリセット上書き）'))
        sd.addWidget(self.mode_combo)
        self.chk_ortho   = QCheckBox('オルソ画像をQGISに読み込む')
        self.chk_dsm     = QCheckBox('DSMをQGISに読み込む')
        self.chk_dtm     = QCheckBox('DTMをQGISに読み込む')
        self.chk_chm     = QCheckBox('CHMを作成してQGISに読み込む')
        self.chk_pc      = QCheckBox('点群を保存・読み込む（容量大）')
        for chk in (self.chk_ortho, self.chk_dsm, self.chk_dtm, self.chk_chm, self.chk_pc):
            sd.addWidget(chk)
        detail_group.setLayout(sd)
        s3.addWidget(detail_group)
        layout.addWidget(self.step3_group)

        # ══ STEP 4: 実行 ══
        self.step4_group = QGroupBox('④ 解析を実行')
        s4 = QVBoxLayout(self.step4_group)

        btn_row = QHBoxLayout()
        self.btn_start = QPushButton('▶  解析開始')
        self.btn_start.setStyleSheet('font-size: 14px; font-weight: bold; padding: 8px;')
        self.btn_cancel = QPushButton('中止')
        self.btn_cancel.setEnabled(False)
        self.btn_start.clicked.connect(self._start_processing)
        self.btn_cancel.clicked.connect(self._cancel_processing)
        btn_row.addWidget(self.btn_start, 3)
        btn_row.addWidget(self.btn_cancel, 1)
        s4.addLayout(btn_row)

        # 進捗
        self.status_label = QLabel('待機中')
        self.status_label.setAlignment(Qt.AlignCenter)
        s4.addWidget(self.status_label)

        self.overall_bar = QProgressBar()
        self.overall_bar.setTextVisible(True)
        s4.addWidget(self.overall_bar)

        sub_form = QFormLayout()
        self.upload_bar     = QProgressBar()
        self.processing_bar = QProgressBar()
        self.download_bar   = QProgressBar()
        self.chm_bar        = QProgressBar()
        for bar in (self.upload_bar, self.processing_bar, self.download_bar, self.chm_bar):
            bar.setMaximumHeight(10)
            bar.setTextVisible(False)
        sub_form.addRow('アップロード', self.upload_bar)
        sub_form.addRow('ODM処理',     self.processing_bar)
        sub_form.addRow('成果物取得',   self.download_bar)
        sub_form.addRow('CHM作成',     self.chm_bar)
        s4.addLayout(sub_form)

        self.time_label = QLabel('')
        self.time_label.setAlignment(Qt.AlignRight)
        s4.addWidget(self.time_label)
        layout.addWidget(self.step4_group)

        # ══ ログ（詳細、折りたたみ） ══
        log_group = QGroupBox('処理ログ（詳細）')
        log_group.setCheckable(True)
        log_group.setChecked(False)
        lg = QVBoxLayout(log_group)
        self.log_edit = QTextEdit()
        self.log_edit.setReadOnly(True)
        self.log_edit.setMaximumHeight(150)
        lg.addWidget(self.log_edit)
        layout.addWidget(log_group)

        layout.addStretch()

        scroll = QScrollArea()
        scroll.setWidget(root)
        scroll.setWidgetResizable(True)
        scroll.setHorizontalScrollBarPolicy(Qt.ScrollBarAlwaysOff)
        self.setWidget(scroll)

        # macOSのDocker DesktopではNVIDIA CUDA版NodeODMを利用できないため無効化
        if platform.system() == 'Darwin':
            for button in (self.btn_pull_gpu, self.btn_start_gpu, self.btn_setup_gpu):
                button.setEnabled(False)
                button.setToolTip('macOSではNVIDIA CUDA GPU版NodeODMは利用できません。CPU版を使用してください。')
            self.btn_pull_gpu.setText('GPU版（macOS非対応）')
            self.btn_start_gpu.setText('GPU版（macOS非対応）')

        # プリセット初期値を適用
        self._on_preset_changed()

    # ══════════════════════════════════════════════════════
    # ステップ表示
    # ══════════════════════════════════════════════════════
    _STEP_GUIDES = [
        '① Docker Desktopの状態を確認しています...',
        '② NodeODMが起動しているか確認しています...',
        '③ ドローン写真フォルダと出力先を選んでください。',
        '④ プリセットを選んで「解析開始」を押してください。',
        '✅ 解析が完了しました。成果物をQGISで確認してください。',
    ]

    def _set_step(self, step: int):
        self._current_step = step
        for i, lbl in enumerate(self._step_labels):
            if i < step:
                lbl.setStyleSheet('color: #888; font-size: 10px;')
            elif i == step:
                lbl.setStyleSheet('color: #007700; font-weight: bold; font-size: 10px;')
            else:
                lbl.setStyleSheet('color: #bbb; font-size: 10px;')
        if step < len(self._STEP_GUIDES):
            self.guide_label.setText(self._STEP_GUIDES[step])

    # ══════════════════════════════════════════════════════
    # プリセット
    # ══════════════════════════════════════════════════════
    _PRESET_DESCS = {
        'forest': '森林調査向け。DSM・DTM・CHM（樹高モデル）を生成します。GeoTivity for QGISでの解析に最適です。',
        'survey': '測量・地形把握向け。高精細なオルソ画像とDSMを生成します。',
        'agri':   '農地・圃場向け。オルソ画像とDSMを生成します。',
        'fast':   '高速モード。オルソ画像のみ生成します。撮影確認や試験処理に適しています。',
    }
    _PRESET_SETTINGS = {
        # (odm_mode, ortho, dsm, dtm, chm, pc)
        'forest': ('chm',      True,  True,  True,  True,  False),
        'survey': ('high',     True,  True,  False, False, False),
        'agri':   ('standard', True,  True,  False, False, False),
        'fast':   ('fast',     True,  False, False, False, False),
    }

    def _on_preset_changed(self):
        key = self.preset_combo.currentData()
        self.preset_desc.setText(self._PRESET_DESCS.get(key, ''))
        if key not in self._PRESET_SETTINGS:
            return
        mode, ortho, dsm, dtm, chm, pc = self._PRESET_SETTINGS[key]
        idx = self.mode_combo.findData(mode)
        if idx >= 0:
            self.mode_combo.setCurrentIndex(idx)
        self.chk_ortho.setChecked(ortho)
        self.chk_dsm.setChecked(dsm)
        self.chk_dtm.setChecked(dtm)
        self.chk_chm.setChecked(chm)
        self.chk_pc.setChecked(pc)

    # ══════════════════════════════════════════════════════
    # 環境診断・NodeODM操作
    # ══════════════════════════════════════════════════════
    def _auto_diagnose(self):
        self._set_step(STEP_DOCKER)
        self._run_env('diagnose')

    def _run_env(self, action):
        if self.env_thread is not None:
            return
        self._set_env_buttons_enabled(False)
        self.env_status_label.setText('確認中...')
        url = self.url_edit.text().strip() or 'http://localhost:3000'
        self.env_thread = QThread(self)
        self.env_worker = EnvWorker(action, url)
        self.env_worker.moveToThread(self.env_thread)
        self.env_thread.started.connect(self.env_worker.run)
        self.env_worker.finished.connect(self._on_env_finished)
        self.env_worker.progress.connect(self._on_env_progress)
        self.env_worker.finished.connect(self.env_thread.quit)
        self.env_thread.finished.connect(self._cleanup_env_thread)
        self.env_thread.start()

    def _on_env_finished(self, action, ok, message):
        if action == 'report':
            QApplication.clipboard().setText(message)
            self._append_log('診断情報をクリップボードにコピーしました')
            self._msg('診断情報をコピーしました。', Qgis.Success)
            return
        if action in ('setup_cpu', 'setup_gpu'):
            QApplication.clipboard().setText(message)
            self._append_log('導入手順をクリップボードにコピーしました')
            shell_name = 'ターミナル' if platform.system() == 'Darwin' else 'PowerShell' if platform.system() == 'Windows' else 'シェル'
            self._msg(f'導入手順をコピーしました。{shell_name}に貼り付けて実行してください。', Qgis.Success)
            return
        if action == 'check_gpu':
            self._append_log(f'GPU診断: {message}')
            self._msg(('GPU利用可能: ' if ok else 'GPU利用不可: ') + message,
                      Qgis.Success if ok else Qgis.Warning)
            return

        # diagnose / start / stop / pull / pull_gpu
        for line in message.splitlines():
            self._append_log(line)

        if action == 'diagnose':
            self.env_status_label.setText(message)
            docker_ok    = 'Docker Desktop: ✓' in message
            docker_run   = 'Docker起動: ✓' in message
            nodeodm_run  = 'NodeODMコンテナ: ✓' in message

            if not docker_ok:
                # ── Docker未導入 ──
                self.env_status_label.setText('Docker Desktopがインストールされていません。')
                self._show_wizard('no_docker')
                self._set_step(STEP_DOCKER)
            elif not docker_run:
                # ── Docker停止中 ──
                self.env_status_label.setText('Docker Desktopが起動していません。')
                self._show_wizard('docker_stopped')
                self._set_step(STEP_DOCKER)
            elif not nodeodm_run:
                # ── NodeODM未起動 → CPU/GPU両方のイメージ有無で分岐 ──
                cpu_img_ok, _ = docker_manager.image_exists(gpu=False)
                gpu_img_ok, _ = docker_manager.image_exists(gpu=True)
                if not (cpu_img_ok or gpu_img_ok):
                    self.env_status_label.setText('NodeODMがまだ導入されていません。')
                    self._show_wizard('no_nodeodm')
                    self._set_step(STEP_NODEODM)
                else:
                    self.env_status_label.setText('NodeODMが起動していません。「NodeODM 起動」を押してください。')
                    self._show_wizard('normal')
                    self._set_step(STEP_NODEODM)
            else:
                # ── 全て正常 ──
                self.env_status_label.setText('✅ 環境OK。写真フォルダを選んでください。')
                self._show_wizard('normal')
                self._set_step(STEP_PHOTOS)

        elif action in ('start', 'start_gpu'):
            if ok:
                self.env_status_label.setText('NodeODMを起動しました。接続を確認しています...')
                self._check_nodeodm_ready()
            else:
                self.env_status_label.setText(_friendly_error(message))
                self._msg(_friendly_error(message), Qgis.Warning)

        elif action == 'stop':
            if ok:
                self.env_status_label.setText('NodeODMを停止しました。')
                self._set_step(STEP_NODEODM)
            else:
                self.env_status_label.setText(_friendly_error(message))

        elif action in ('pull', 'pull_gpu'):
            self.pull_progress_bar.setVisible(False)
            self.pull_status_label.setText(message)
            if ok:
                self._msg('NodeODMの導入が完了しました。「NodeODM 起動」を押してください。', Qgis.Success)
                self.env_status_label.setText('✅ NodeODMの導入完了。「NodeODM 起動」を押してください。')
                self._show_wizard('normal')
                self._set_step(STEP_NODEODM)
            else:
                self._msg(f'NodeODMの導入に失敗しました: {message}', Qgis.Critical)

    def _on_env_progress(self, action, message):
        if action == 'pull_progress':
            self.pull_status_label.setText(message)
            self._append_log(message)

    def _cleanup_env_thread(self):
        if self.env_worker:
            self.env_worker.deleteLater()
            self.env_worker = None
        self.env_thread = None
        self._set_env_buttons_enabled(True)

    def _set_env_buttons_enabled(self, enabled):
        for b in (self.btn_diagnose, self.btn_start_nodeodm, self.btn_start_gpu,
                  self.btn_stop, self.btn_setup_cpu, self.btn_setup_gpu, self.btn_diag_copy,
                  self.btn_open_docker_url, self.btn_show_docker_guide,
                  self.btn_diagnose_no_docker, self.btn_diagnose_stopped,
                  self.btn_diagnose_no_nodeodm,
                  self.btn_pull, self.btn_pull_gpu):
            b.setEnabled(enabled)
        # pull中はプログレスバーを表示
        if not enabled and self.env_worker and self.env_worker.action in ('pull', 'pull_gpu'):
            self.pull_progress_bar.setVisible(True)
        elif enabled:
            self.pull_progress_bar.setVisible(False)

    def _show_wizard(self, state: str):
        """state: 'no_docker' | 'docker_stopped' | 'no_nodeodm' | 'normal'"""
        self.wizard_no_docker.setVisible(state == 'no_docker')
        self.wizard_docker_stopped.setVisible(state == 'docker_stopped')
        self.wizard_no_nodeodm.setVisible(state == 'no_nodeodm')
        self.wizard_normal.setVisible(state == 'normal')

    def _open_docker_install_page(self):
        from qgis.PyQt.QtGui import QDesktopServices
        from qgis.PyQt.QtCore import QUrl
        QDesktopServices.openUrl(QUrl(docker_manager.docker_install_url()))
        self._append_log('Docker Desktopインストールページを開きました')
        self._msg('ブラウザでDocker Desktopのダウンロードページを開きました。', Qgis.Info)

    def _show_docker_start_guide(self):
        guide = docker_manager.docker_start_guide()
        self.docker_guide_label.setText(guide)
        self.docker_guide_label.setVisible(True)
        self._append_log('Docker起動方法を表示しました')

    def _check_nodeodm_ready(self, retries=6, interval=5):
        # 既に確認中なら二重起動しない
        if self.ready_thread is not None:
            return
        url = self.url_edit.text().strip() or 'http://localhost:3000'

        class ReadyChecker(QObject):
            ready = pyqtSignal(bool, str)
            def __init__(self, url, retries, interval):
                super().__init__()
                self._url, self._retries, self._interval = url, retries, interval
            def run(self):
                for attempt in range(1, self._retries + 1):
                    try:
                        NodeODMClient(self._url, timeout=5).test_connection()
                        self.ready.emit(True, f'NodeODM接続確認（{attempt}回目）')
                        return
                    except Exception:
                        pass
                    time.sleep(self._interval)
                self.ready.emit(False, 'NodeODMが応答しません。')

        self.ready_thread = QThread(self)
        self.ready_checker = ReadyChecker(url, retries, interval)
        self.ready_checker.moveToThread(self.ready_thread)
        self.ready_thread.started.connect(self.ready_checker.run)
        self.ready_checker.ready.connect(self._on_nodeodm_ready)
        # ready受信後にスレッドを終了し、終了後にオブジェクトを解放（順序が重要）
        self.ready_checker.ready.connect(self.ready_thread.quit)
        self.ready_thread.finished.connect(self._cleanup_ready_thread)
        self.ready_thread.start()

    def _on_nodeodm_ready(self, ok, msg):
        self._append_log(msg)
        if ok:
            self.env_status_label.setText('✅ NodeODMが起動しました。写真フォルダを選んでください。')
            self._msg('NodeODMが起動しました。解析を開始できます。', Qgis.Success)
            self._set_step(STEP_PHOTOS)
        else:
            self.env_status_label.setText(
                'NodeODMの起動確認がタイムアウトしました。\n「もう一度確認」を押して状態を確認してください。'
            )
            self._msg('NodeODMの起動確認に失敗しました。', Qgis.Warning)

    def _cleanup_ready_thread(self):
        # checker → thread の順で解放（逆順にするとクラッシュの可能性）
        if self.ready_checker:
            self.ready_checker.deleteLater()
            self.ready_checker = None
        self.ready_thread = None

    # ══════════════════════════════════════════════════════
    # 接続テスト
    # ══════════════════════════════════════════════════════
    def _test_connection(self):
        url = self.url_edit.text().strip()
        if not url:
            self._msg('URLを入力してください。', Qgis.Warning)
            return
        self.connection_label.setText('接続確認中...')
        try:
            NodeODMClient(url, timeout=10).test_connection()
            self.connection_label.setText('✅ 接続しました')
            self._msg('NodeODMに接続しました。', Qgis.Success)
            self._save_settings()
        except Exception as exc:
            self.connection_label.setText('✗ 接続できません')
            self._msg(_friendly_error(str(exc)), Qgis.Critical)

    # ══════════════════════════════════════════════════════
    # フォルダ選択
    # ══════════════════════════════════════════════════════
    def _select_image_folder(self):
        folder = QFileDialog.getExistingDirectory(self, '写真フォルダを選択', self.image_folder_edit.text())
        if folder:
            self.image_folder_edit.setText(folder)
            self._save_settings()
            self._show_photo_count(folder)
            if self._current_step == STEP_PHOTOS:
                self._set_step(STEP_RUN)

    def _select_output_folder(self):
        folder = QFileDialog.getExistingDirectory(self, '出力フォルダを選択', self.output_folder_edit.text())
        if folder:
            self.output_folder_edit.setText(folder)
            self._save_settings()

    def _show_photo_count(self, folder):
        exts = {'.jpg', '.jpeg', '.tif', '.tiff'}
        files = [p for p in Path(folder).rglob('*') if p.is_file() and p.suffix.lower() in exts]
        size_gb = sum(p.stat().st_size for p in files) / (1024 ** 3) if files else 0
        if len(files) == 0:
            self.photo_count_label.setText('⚠ 写真が見つかりません（JPEG/TIFFを確認してください）')
        elif len(files) < 20:
            self.photo_count_label.setText(f'⚠ {len(files)}枚 / {size_gb:.2f} GB（ODM処理には20枚以上を推奨）')
        else:
            self.photo_count_label.setText(f'✅ {len(files)}枚 / {size_gb:.2f} GB')
        self._append_log(f'写真確認: {len(files)}枚 / {size_gb:.2f} GB')

    # ══════════════════════════════════════════════════════
    # 解析実行
    # ══════════════════════════════════════════════════════
    def _collect_params(self):
        url = self.url_edit.text().strip() or 'http://localhost:3000'
        image_folder = self.image_folder_edit.text().strip()
        output_folder = self.output_folder_edit.text().strip()
        if not image_folder or not os.path.isdir(image_folder):
            raise ValueError('写真フォルダを選択してください。')
        if not output_folder:
            raise ValueError('出力フォルダを選択してください。')
        Path(output_folder).mkdir(parents=True, exist_ok=True)
        project_name = self.project_name_edit.text().strip()
        if not project_name:
            project_name = f'odm_{datetime.now().strftime("%Y%m%d_%H%M%S")}'
        safe_name = ''.join(c if c.isalnum() or c in ('-', '_') else '_' for c in project_name)
        if self.chk_chm.isChecked() and not (self.chk_dsm.isChecked() and self.chk_dtm.isChecked()):
            raise ValueError('CHM作成にはDSMとDTMが必要です。プリセット「森林」を選んでください。')
        return {
            'nodeodm_url': url,
            'image_folder': image_folder,
            'output_folder': output_folder,
            'project_name': safe_name,
            'mode': self.mode_combo.currentData(),
            'load_flags': {
                'orthophoto': self.chk_ortho.isChecked(),
                'dsm':        self.chk_dsm.isChecked(),
                'dtm':        self.chk_dtm.isChecked(),
                'chm':        self.chk_chm.isChecked(),
                'pointcloud': self.chk_pc.isChecked(),
            },
        }

    def _start_processing(self):
        if self.is_running:
            self._msg('処理中です。', Qgis.Warning)
            return
        try:
            params = self._collect_params()
        except ValueError as exc:
            self._msg(str(exc), Qgis.Warning)
            return
        self._save_settings()
        self._reset_bars()
        self.is_running = True
        self.btn_start.setEnabled(False)
        self.btn_cancel.setEnabled(True)
        self.started_at = datetime.now()
        self.status_label.setText('処理を開始しています...')
        self._set_step(STEP_RUN)
        self._append_log(f'解析開始: プリセット={self.preset_combo.currentText()} / モード={params["mode"]}')

        self.thread = QThread(self)
        self.worker = ODMWorker(params)
        self.worker.moveToThread(self.thread)
        self.thread.started.connect(self.worker.run)
        self.worker.log.connect(self._append_log)
        self.worker.progress.connect(self._on_progress)
        self.worker.stage_progress.connect(self._on_stage_progress)
        self.worker.finished.connect(self._on_finished)
        self.worker.error.connect(self._on_error)
        self.worker.finished.connect(self.thread.quit)
        self.worker.error.connect(self.thread.quit)
        self.thread.finished.connect(self._cleanup_thread)
        self.thread.start()

    def _cancel_processing(self):
        if self.worker:
            self._append_log('処理の中止を要求しました...')
            self.status_label.setText('中止しています...')
            self.worker.request_cancel()
        self.btn_cancel.setEnabled(False)

    def _reset_bars(self):
        for bar in (self.overall_bar, self.upload_bar, self.processing_bar,
                    self.download_bar, self.chm_bar):
            bar.setValue(0)

    def _on_progress(self, percent, status):
        self.overall_bar.setValue(percent)
        self.status_label.setText(status)
        if self.started_at:
            elapsed = datetime.now() - self.started_at
            s = int(elapsed.total_seconds())
            h, rem = divmod(s, 3600)
            m, sec = divmod(rem, 60)
            self.time_label.setText(f'経過: {h:02d}:{m:02d}:{sec:02d}')

    def _on_stage_progress(self, stage, percent):
        mapping = {
            'upload':     self.upload_bar,
            'processing': self.processing_bar,
            'download':   self.download_bar,
            'chm':        self.chm_bar,
        }
        if stage in mapping:
            mapping[stage].setValue(percent)

    def _on_finished(self, result):
        outputs = result.get('outputs', {})
        flags   = result.get('load_flags', {})
        loaded  = []
        try:
            if flags.get('orthophoto') and outputs.get('orthophoto'):
                if self._load_raster(outputs['orthophoto'], 'ODM オルソ画像'):
                    loaded.append('オルソ画像')
            if flags.get('dsm') and outputs.get('dsm'):
                if self._load_raster(outputs['dsm'], 'ODM DSM'):
                    loaded.append('DSM')
            if flags.get('dtm') and outputs.get('dtm'):
                if self._load_raster(outputs['dtm'], 'ODM DTM'):
                    loaded.append('DTM')
            if flags.get('chm') and outputs.get('dsm') and outputs.get('dtm'):
                chm_path = str(Path(result['project_dir']) / 'elevation' / 'chm.tif')
                if self._create_chm(outputs['dsm'], outputs['dtm'], chm_path):
                    outputs['chm'] = chm_path
                    if self._load_raster(chm_path, 'ODM CHM（樹高モデル）'):
                        loaded.append('CHM（樹高モデル）')
            if flags.get('pointcloud') and outputs.get('pointcloud'):
                if self._load_pointcloud(outputs['pointcloud'], 'ODM 点群'):
                    loaded.append('点群')
        except Exception as exc:
            friendly = _friendly_error(str(exc))
            self._append_log(f'QGIS読込エラー（詳細）: {exc}')
            self._msg(f'成果物の読み込み中にエラーが発生しました: {friendly}', Qgis.Warning)

        self.overall_bar.setValue(100)
        self.btn_start.setEnabled(True)
        self.btn_cancel.setEnabled(False)
        self.is_running = False
        self._set_step(STEP_DONE)

        if loaded:
            summary = '解析完了！ QGISに追加しました: ' + '・'.join(loaded)
            self.status_label.setText('✅ ' + summary)
            self._msg(summary, Qgis.Success)
            QMessageBox.information(self, 'GeoTivity Drone Tools', summary)
        else:
            self.status_label.setText('解析完了（成果物の読み込みなし）')
        self._append_log(f'解析完了: {", ".join(loaded) if loaded else "なし"}')

    def _on_error(self, message):
        self.btn_start.setEnabled(True)
        self.btn_cancel.setEnabled(False)
        self.is_running = False
        self.status_label.setText('⚠ エラーが発生しました')
        friendly = _friendly_error(message)
        self._append_log(f'エラー（詳細）: {message}')

        # 原因候補を状況に応じて付加
        hint = _error_hint(message)
        display = friendly if not hint else f'{friendly}\n\n{hint}'
        self._msg(friendly, Qgis.Critical)
        QMessageBox.warning(self, 'GeoTivity Drone Tools', display)

    def _cleanup_thread(self):
        if self.worker:
            self.worker.deleteLater()
            self.worker = None
        self.thread = None

    # ══════════════════════════════════════════════════════
    # QGIS レイヤー読込・CHM作成
    # ══════════════════════════════════════════════════════
    def _load_raster(self, path, name):
        layer = QgsRasterLayer(path, name)
        if not layer.isValid():
            self._append_log(f'ラスタ読込失敗: {path}')
            return False
        QgsProject.instance().addMapLayer(layer)
        self._append_log(f'QGISに追加: {name}')
        return True

    def _load_pointcloud(self, path, name):
        try:
            layer = QgsPointCloudLayer(path, name, 'pdal')
            if not layer.isValid():
                self._append_log(f'点群読込失敗: {path}')
                return False
            QgsProject.instance().addMapLayer(layer)
            self._append_log(f'QGISに追加: {name}')
            return True
        except Exception as exc:
            self._append_log(f'点群読込失敗（詳細）: {exc}')
            return False

    def _create_chm(self, dsm_path, dtm_path, chm_path):
        if QgsRasterCalculator is None or QgsRasterCalculatorEntry is None:
            self._append_log('QgsRasterCalculatorを利用できないためCHM作成をスキップしました。')
            return False
        dsm = QgsRasterLayer(dsm_path, 'DSM_tmp')
        dtm = QgsRasterLayer(dtm_path, 'DTM_tmp')
        if not dsm.isValid() or not dtm.isValid():
            self._append_log('DSMまたはDTMが無効なためCHM作成をスキップしました。')
            return False
        Path(chm_path).parent.mkdir(parents=True, exist_ok=True)
        entries = []
        for ref, lyr in (('dsm@1', dsm), ('dtm@1', dtm)):
            e = QgsRasterCalculatorEntry()
            e.ref = ref
            e.raster = lyr
            e.bandNumber = 1
            entries.append(e)
        expression = '((dsm@1 - dtm@1) > 0) * (dsm@1 - dtm@1)'
        calc = QgsRasterCalculator(
            expression, chm_path, 'GTiff',
            dsm.extent(), dsm.width(), dsm.height(), entries,
        )
        result = calc.processCalculation()
        if result != 0:
            self._append_log(f'CHM作成失敗: result={result}')
            return False
        self.chm_bar.setValue(100)
        self._append_log(f'CHM作成完了: {chm_path}')
        return True

    # ══════════════════════════════════════════════════════
    # 設定保存・読込
    # ══════════════════════════════════════════════════════
    def _load_settings(self):
        self.url_edit.setText(self.settings.value(f'{SETTINGS_PREFIX}/url', 'http://localhost:3000'))
        self.image_folder_edit.setText(self.settings.value(f'{SETTINGS_PREFIX}/image_folder', ''))
        self.output_folder_edit.setText(self.settings.value(f'{SETTINGS_PREFIX}/output_folder', ''))
        preset = self.settings.value(f'{SETTINGS_PREFIX}/preset', 'forest')
        idx = self.preset_combo.findData(preset)
        if idx >= 0:
            self.preset_combo.setCurrentIndex(idx)

    def _save_settings(self):
        self.settings.setValue(f'{SETTINGS_PREFIX}/url', self.url_edit.text().strip())
        self.settings.setValue(f'{SETTINGS_PREFIX}/image_folder', self.image_folder_edit.text().strip())
        self.settings.setValue(f'{SETTINGS_PREFIX}/output_folder', self.output_folder_edit.text().strip())
        self.settings.setValue(f'{SETTINGS_PREFIX}/preset', self.preset_combo.currentData())

    # ══════════════════════════════════════════════════════
    # ログ・メッセージ
    # ══════════════════════════════════════════════════════
    def _append_log(self, message):
        if not message:
            return
        if not re.match(r'^\d{4}-\d{2}-\d{2} \d{2}:\d{2}:\d{2} ', str(message)):
            message = f'{datetime.now().strftime("%Y-%m-%d %H:%M:%S")} {message}'
        self.log_edit.append(str(message))
        self.log_edit.moveCursor(QTextCursor.End)
        QgsMessageLog.logMessage(str(message), 'GeoTivity Drone Tools', Qgis.Info)

    def _msg(self, message, level):
        self.iface.messageBar().pushMessage('GeoTivity Drone Tools', message, level=level, duration=6)
